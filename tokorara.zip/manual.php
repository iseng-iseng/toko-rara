<?php 
include 'header.php';
?>

<style type="text/css">
    .bs-acc{
        margin: 20px;
    }
</style>
<div class="container">
		<h2 style=" width: 100%; border-bottom: 4px solid #ebaaff"><b>Manual Aplikasi</b></h2>
	<div class="bs-acc">
		<div class="panel-group" id="accordion">
			<div class="panel panel-default">
				<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" style="color:#000;">
				<div class="panel-heading" style="background-color: #eee;">
					<h4 class="panel-title">
						Bagaimana Cara Berbelanja di Preloved Buttonscarves Rara ?
					</h4>
				</div>
				</a>
				<div id="collapseOne" class="panel-collapse collapse in">
					<div class="panel-body">
						<ol>
							<li>Pastikan anda Daftar/Register terlebih dahulu</li>
							<li>Jika sudah punya akun silahkan Login</li>
							<li>Pilih produk yang diinginkan</li>
							<li>Tambahkan ke keranjang</li>
							<li>Checkout pesanan anda</li>
							<li>Masukkan alamat pengiriman</li>
							<li>Klik order sekarang</li>
						</ol>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>


<?php 
include 'footer.php';
?>