<?php 
	include 'header.php';
 ?>


<div class="container" style="padding-bottom: 300px;">
	<h2 style=" width: 100%; border-bottom: 4px solid #ebaaff"><b>Tentang Kami</b></h2>
	<p class="text-justify">Siapa yang tidak mengenal Buttonscarves? Buttonscarves menjadi salah satu brand lokal di ranah fashion dan lifestyle yang paling dikenal oleh masyarakat Indonesia khususnya para perempuan, brand tersebut didirikan oleh Linda Anggrea di awal tahun 2016. Tak hanya menjual hijab (scarf), Buttonscarves juga menawarkan berbagai produk lainnya, seperti mukenah, tas, sepatu, aksesoris, dan beauty products.</p>
<p>
Pada Preloved Buttonscarves Rara, kalian dapat menemukan barang-barang yang sudah habis di toko, disini terdapat produk yang telah dipakai hanya satu kali dengan kualitas masih sama seperti barang baru, dan terdapat juga produk baru yang belum dipakai sama sekali.</p>
</div>




 <?php 
	include 'footer.php';
 ?>