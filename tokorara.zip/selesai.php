<?php 
	include 'header.php';
 ?>

<div class="container" style="padding-bottom: 300px;">
	<h2 class="bg-success text-center" style="padding: 10px;">Checkout Berhasil</h2>
	<h4 class="text-center" style="font-weight: bold;">Terimakasih sudah berbelanja di Preloved Buttonscarves Rara, pesananmu sedang diproses silahkan tunggu barangmu sampai dirumah ya!!! :)</h4>
	
</div>

 <?php 
	include 'footer.php';
 ?>