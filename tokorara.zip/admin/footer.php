<footer style="background-color: gray;padding: 1px;" class="print">
	<h5 class="text-center">Made By &copy; Rahadani Syifariani</h5>
</footer>
</body>
</html>