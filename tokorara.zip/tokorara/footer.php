
	<footer style="border-top: 4px solid #ebaaff;  ">
		<div class="container" style="padding-bottom: 50px;">
			<div class="row">
				<div class="col-md-4">
					<h3 style="color: #ebaaff"><b>PRELOVED BUTTONSCARVES</b></h3>
					<p>Jl. Pulau Rangas C7/5</p>
					<p><i class="glyphicon glyphicon-earphone"></i> +6281398135855</p>
					<p><i class="glyphicon glyphicon-envelope"></i> prelovedrara@gmail.com</p>
				</div>
				<div class="col-md-4">
					<h5><b>Menu</b></h5>
					<p><a href="produk.php"  style="color: #000">Produk</a></p>
					<p><a href="about.php"  style="color: #000">Tentang kami</a></p>
					<p><a href="manual.php"  style="color: #000">Manual Aplikasi</a></p>
				</div>

				<div class="col-md-4">
					
				</div>
			</div>

		</div>

		<div class="copy" style="background-color: #ebaaff; padding: 5px; color: #fff; text-align: center;">
			<span>Made By &copy; Rahadani Syifariani</span>
		</div>
	</footer>

</body>
</html>